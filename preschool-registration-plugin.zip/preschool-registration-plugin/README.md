# Plugin Installation and Activation Guide

This guide provides instructions for installing and activating the Preschool Registration Plugin, along with example GET requests and their expected return values.

## Installation

1. Download the plugin zip file from the GitHub repository.
2. Locate the root folder of your website and navigate to the `wp-content` directory.
3. Inside the `wp-content` directory, find the `plugins` folder and extract the contents of the downloaded zip file into this folder.

## Activation

1. Access your WordPress Dashboard and click on the "Plugins" tab.
2. Look for the newly added plugin named "Preschool Registration" in the list.
3. Click the "Activate" button next to the "Preschool Registration" plugin to activate it.

## Example GET requests

### Request 1: Get Preschool Details based on Post ID

- URL: `http://preschool-registration.local/wp-json/preschool-reg/v1/15`
- Method: GET

### Expected Response

```json
{
    "id":"15",
    "preschool_name":"Little Explorers",
    "preschool_address":"123 Main Street, Philadelphia, PA 19101",
    "registration_days":["Mon","Wed","Fri"],
    "registration_time_start":"11:00",
    "registration_time_end":"16:00",
    "accepting_registrations":"on"
}
```

### Request 2: Get Preschool Details based on **incorrect** Post ID

- URL: `http://preschool-registration.local/wp-json/preschool-reg/v1/20`
- Method: GET

### Expected Response

```json
{
    "code":"invalid_post_id",
    "message":"Invalid Post ID.",
    "data":
    {
        "status":400
    }
}
```

You can try for post IDs 15, 16, 17, 18, 19

### Request 3: Get Preschools based on registration date and time 

  - URL: `http://preschool-registration.local/wp-json/preschool-reg/v1/filter?registration_time=2023-06-02T13:00:00`
- Method: GET

### Expected Response

```json
[
    {
        "id":19,
        "preschool_name":"Little Sprouts",
        "preschool_address":"987 Pine Road, Philadelphia, PA 19105",
        "registration_days":["Mon","Wed","Fri"],
        "registration_time_start":"11:00",
        "registration_time_end":"16:00",
        "accepting_registrations":"on"
    },
    {
        "id":15,
        "preschool_name":"Little Explorers",
        "preschool_address":"123 Main Street, Philadelphia, PA 19101",
        "registration_days":["Mon","Wed","Fri"],
        "registration_time_start":"11:00",
        "registration_time_end":"16:00",
        "accepting_registrations":"on"
    }
]
```

### Request 4: Get Preschools based on registration date and time but no available preschools

  - URL: `http://preschool-registration.local/wp-json/preschool-reg/v1/filter?registration_time=2023-06-03T13:00:00`
- Method: GET

### Expected Response

```json
[]
```

The time would have to be passed as 24 hour.

# Design Considerations and Choices

