<?php
/*
Plugin Name: Preschool Registration Plugin
Plugin URI: https://example.com/
Description: Custom plugin for preschool registration.
Version: 1.0.0
Author: Ritika Desai
Author URI: https://example.com/
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: preschool-registration-plugin
*/

// Step 2: Create a custom post type called “preschool-registration”

// Create a function for a custom post type  
function custom_register_preschool_post_type() {
    // Define a set of labels and their values for the custom post type
    $labels = array(
        'name'               => 'Preschool Registrations',
        'singular_name'      => 'Preschool Registration',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Preschool Registration',
        'edit_item'          => 'Edit Preschool Registration',
        'new_item'           => 'New Preschool Registration',
        'view_item'          => 'View Preschool Registration',
        'search_items'       => 'Search Preschool Registrations',
        'not_found'          => 'No preschool registrations found',
        'not_found_in_trash' => 'No preschool registrations found in trash',
        'menu_name'          => 'Preschool Registrations'
    );

    // Pass required arguments for the custom post type
    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'show_in_rest'        => true,      
        'has_archive'         => true,
        'supports'            => array( 'title' ),
        'rewrite'             => array( 'slug' => 'preschool-reg' ),
    );

    // Register the post type with a slug and the arguments 
    register_post_type( 'preschool-reg', $args );
}

// Step 3: Add the following custom fields
// a. Name of preschool
// b. Address
// c. Time of registration during the week (ex. Mon Wed Fri 11AM - 4PM, Tues Thurs 9AM - 2PM)
// d. Location accepting registrations? Y/N

// Create a function to add custom fields for the custom post type 
function add_preschool_registration_custom_fields() {
    add_meta_box(
        'preschool_registration_fields',
        'Preschool Registration Details',
        'render_preschool_registration_fields',
        'preschool-reg',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_preschool_registration_custom_fields');

function render_preschool_registration_fields($post) {
    // Retrieve the current values for the custom fields
    $preschool_name = get_post_meta($post->ID, 'preschool_name', true);
    $address = get_post_meta($post->ID, 'address', true);
    $registration_days = get_post_meta($post->ID, 'registration_days', true);
    $registration_time_start = get_post_meta($post->ID, 'registration_time_start', true);
    $registration_time_end = get_post_meta($post->ID, 'registration_time_end', true);
    $accepting_registrations = get_post_meta($post->ID, 'accepting_registrations', true);

    // Define the days of the week
    $days_of_week = array(
        'Monday' => 'Mon',
        'Tuesday' => 'Tue',
        'Wednesday' => 'Wed',
        'Thursday' => 'Thu',
        'Friday' => 'Fri',
        'Saturday' => 'Sat',
        'Sunday' => 'Sun',
    );

    // Output the custom fields HTML
    ?>
    <div>
    <label for="preschool_name">Name of Preschool:</label>
    <input type="text" id="preschool_name" name="preschool_name" value="<?php echo esc_attr($preschool_name); ?>" />
    </div>
    <br/>

    <div>
    <label for="address">Address:</label>
    <textarea id="address" name="address" rows="1" cols="50"><?php echo esc_textarea($address); ?></textarea> 
    </div>
    <br/>

    <div>
    <label for="registration_days">Registration Days:</label><br/>
    <?php foreach ($days_of_week as $day => $short_day) { ?>
        <input type="checkbox" id="registration_day_<?php echo esc_attr($short_day); ?>" name="registration_days[]" value="<?php echo esc_attr($short_day); ?>" <?php if (is_array($registration_days) && in_array($short_day, $registration_days)) echo 'checked'; ?> />
        <label for="registration_day_<?php echo esc_attr($short_day); ?>"><?php echo esc_html($day); ?></label><br/>
    <?php } ?>
    </div>
    <br />

    <div>
    <label for="registration_time_start">Registration Time Start:</label>
    <input type="time" id="registration_time_start" name="registration_time_start" value="<?php echo esc_attr($registration_time_start); ?>" />
    </div>
    <br />
    
    <div>
    <label for="registration_time_end">Registration Time End:</label>
    <input type="time" id="registration_time_end" name="registration_time_end" value="<?php echo esc_attr($registration_time_end); ?>" />
    </div>
    <br />

    <div>
    <label for="accepting_registrations">Accepting Registrations?</label>
    <input type="checkbox" id="accepting_registrations" name="accepting_registrations" <?php checked($accepting_registrations, 'on'); ?> />
    </div>
    <?php
}

// create a function to save the custom fields
function save_preschool_registration_custom_fields($post_id) {
    if (isset($_POST['preschool_name'])) {
        update_post_meta($post_id, 'preschool_name', sanitize_text_field($_POST['preschool_name']));
    }

    if (isset($_POST['address'])) {
        update_post_meta($post_id, 'address', sanitize_textarea_field($_POST['address']));
    }

    if (isset($_POST['registration_days'])) {
        update_post_meta($post_id, 'registration_days', array_map('sanitize_text_field', $_POST['registration_days']));
    } else {
        delete_post_meta($post_id, 'registration_days');
    }

    if (isset($_POST['registration_time_start'])) {
        update_post_meta($post_id, 'registration_time_start', sanitize_text_field($_POST['registration_time_start']));
    }

    if (isset($_POST['registration_time_end'])) {
        update_post_meta($post_id, 'registration_time_end', sanitize_text_field($_POST['registration_time_end']));
    }

    if (isset($_POST['accepting_registrations'])) {
        update_post_meta($post_id, 'accepting_registrations', 'on');
    } else {
        delete_post_meta($post_id, 'accepting_registrations');
    }
}   

// Create a function for steps 4 & 5 to register a route for the request

function extend_preschool_registration_rest_api() {

    // Register route for step 4: Extend the “preschool-registration” CPT REST API so 
    // that all of the above fields are returned. 

    register_rest_route(
        'preschool-reg/v1',
        '/(?P<id>\d+)',
        array(
            'methods'  => 'GET',
            'callback' => 'get_preschool_registration',
        )
    );

    // Register a route for step 5: Extend the “preschool-registration” CPT REST API to 
    // accept a datetime query parameter “registration_time” that filters all available 
    // preschools to only those that are ready for registration and are available at the 
    // requested day / time of the week.

    register_rest_route(
        'preschool-reg/v1',
        '/filter',
        array(
            'methods'  => 'GET',
            'callback' => 'get_filtered_preschool_registrations',
        )
    );
}

// Create a function to return the custom fields based on post ID passed in the URL

function get_preschool_registration($request) {
    $post_id = $request->get_param('id');

    // Return an error if there's no post id
    if (empty($post_id)) {
        return new WP_Error('empty_post_id', 'Post ID is empty.', array('status' => 400));
    }

    $post = get_post($post_id);

    // Return error if the post is empty or the id is not of a post that is of preschool-reg type
    if (empty($post) || $post->post_type !== 'preschool-reg') {
        return new WP_Error('invalid_post_id', 'Invalid Post ID.', array('status' => 400));
    }

    // Create an array of all the fields that are to be returned
    $response = array(
        'id'                          => $post_id,
        'preschool_name'              => get_post_meta($post_id, 'preschool_name', true),
        'preschool_address'           => get_post_meta($post_id, 'address', true),
        'registration_days'           => get_post_meta($post_id, 'registration_days', true),
        'registration_time_start'     => get_post_meta($post_id, 'registration_time_start', true),
        'registration_time_end'       => get_post_meta($post_id, 'registration_time_end', true),
        'accepting_registrations'     => get_post_meta($post_id, 'accepting_registrations', true),
    );

    return $response;

}

// Create a function to return the custom fields based on date and time passed in the URL
function get_filtered_preschool_registrations($request) {
    $registration_time = $request->get_param('registration_time');

    // Create an array for the conditions to be met 

    // Conditions are: 

    // 1. On passing the date we first convert it to the day of the week and then check
    // which schools are taking registrations on that day

    // 2. Extract the time of registration and pass the time component. Then we check if the
    // passed time is on or after the start time and on or before the end time

    // 3. Lastly we check if the preschool is accepting registrations currently

    // All the conditions are bound with an AND so if any one fails, that preschool will be 
    // eliminated from the response

    $args = array(
        'post_type'      => 'preschool-reg',
        'posts_per_page' => -1,
        'meta_query'     => array(
            'relation' => 'AND',
             array(
                'key'     => 'registration_days',
                'value'   => date('D', strtotime($registration_time)),
                'compare' => 'LIKE',
            ),
            array(
                'relation' => 'AND',
                array(
                    'key'     => 'registration_time_start',
                    'value'   => date('H:i:s', strtotime($registration_time)),
                    'compare' => '<=',                    
                ),
                array(
                    'key'     => 'registration_time_end',
                    'value'   => date('H:i:s', strtotime($registration_time)),
                    'compare' => '>=',                    
                ),            
            ),
            array(
                'key'     => 'accepting_registrations',
                'value'   => 'on',
                'compare' => '=',
            ),                       
        ),
    );

    // These arguments are then passed to a Wordpress Query
    $query = new WP_Query($args);

    $responses = array();

    // Iterating while posts exists
    while ($query->have_posts()) {
        $query->the_post();
        // Create an array of all the fields that are to be returned
        $response = array(
            'id'                      => get_the_ID(),
            'preschool_name'          => get_post_meta(get_the_ID(), 'preschool_name', true),
            'preschool_address'       => get_post_meta(get_the_ID(), 'address', true),
            'registration_days'       => get_post_meta(get_the_ID(), 'registration_days', true),
            'registration_time_start' => get_post_meta(get_the_ID(), 'registration_time_start', true),
            'registration_time_end'   => get_post_meta(get_the_ID(), 'registration_time_end', true),
            'accepting_registrations' => get_post_meta(get_the_ID(), 'accepting_registrations', true),
        );
        $responses[] = $response;
    }

    // restore the global variable to the original post data
    wp_reset_postdata(); 
    return $responses;
}

// Add all the three actions 
add_action('rest_api_init', 'extend_preschool_registration_rest_api');
add_action('save_post', 'save_preschool_registration_custom_fields');
add_action('init', 'custom_register_preschool_post_type');
