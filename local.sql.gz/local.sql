-- Adminer 4.8.1 MySQL 8.0.16 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1,	2,	'_wp_page_template',	'default'),
(2,	3,	'_wp_page_template',	'default'),
(44,	15,	'_edit_last',	'1'),
(45,	15,	'_edit_lock',	'1685686125:1'),
(46,	15,	'preschool_name',	'Little Explorers'),
(47,	15,	'address',	'123 Main Street, Philadelphia, PA 19101'),
(48,	15,	'registration_days',	'a:3:{i:0;s:3:\"Mon\";i:1;s:3:\"Wed\";i:2;s:3:\"Fri\";}'),
(49,	15,	'registration_time_start',	'11:00'),
(50,	15,	'registration_time_end',	'16:00'),
(51,	15,	'accepting_registrations',	'on'),
(52,	16,	'_edit_last',	'1'),
(53,	16,	'_edit_lock',	'1685684259:1'),
(54,	16,	'preschool_name',	'Bright Beginnings'),
(55,	16,	'address',	'456 Elm Avenue, Philadelphia, PA 19102'),
(56,	16,	'registration_days',	'a:2:{i:0;s:3:\"Tue\";i:1;s:3:\"Thu\";}'),
(57,	16,	'registration_time_start',	'09:00'),
(58,	16,	'registration_time_end',	'14:00'),
(59,	16,	'accepting_registrations',	'on'),
(60,	17,	'_edit_last',	'1'),
(61,	17,	'_edit_lock',	'1685686115:1'),
(62,	17,	'preschool_name',	'Playful Pals'),
(63,	17,	'address',	'789 Oak Drive, Philadelphia, PA 19103'),
(64,	17,	'registration_days',	'a:3:{i:0;s:3:\"Mon\";i:1;s:3:\"Wed\";i:2;s:3:\"Fri\";}'),
(65,	17,	'registration_time_start',	'11:00'),
(66,	17,	'registration_time_end',	'16:00'),
(67,	18,	'_edit_last',	'1'),
(68,	18,	'_edit_lock',	'1685684320:1'),
(69,	18,	'preschool_name',	'Sunny Days'),
(70,	18,	'address',	'321 Maple Lane, Philadelphia, PA 19104'),
(71,	18,	'registration_days',	'a:2:{i:0;s:3:\"Tue\";i:1;s:3:\"Thu\";}'),
(72,	18,	'registration_time_start',	'09:00'),
(73,	18,	'registration_time_end',	'14:00'),
(74,	18,	'accepting_registrations',	'on'),
(75,	19,	'_edit_last',	'1'),
(76,	19,	'_edit_lock',	'1685686111:1'),
(77,	19,	'preschool_name',	'Little Sprouts'),
(78,	19,	'address',	'987 Pine Road, Philadelphia, PA 19105'),
(79,	19,	'registration_days',	'a:3:{i:0;s:3:\"Mon\";i:1;s:3:\"Wed\";i:2;s:3:\"Fri\";}'),
(80,	19,	'registration_time_start',	'11:00'),
(81,	19,	'registration_time_end',	'16:00'),
(82,	19,	'accepting_registrations',	'on');

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1,	1,	'2023-06-02 05:03:24',	'2023-06-02 05:03:24',	'<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->',	'Hello world!',	'',	'publish',	'open',	'open',	'',	'hello-world',	'',	'',	'2023-06-02 05:03:24',	'2023-06-02 05:03:24',	'',	0,	'http://preschool-registration.local/?p=1',	0,	'post',	'',	1),
(2,	1,	'2023-06-02 05:03:24',	'2023-06-02 05:03:24',	'<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://preschool-registration.local/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->',	'Sample Page',	'',	'publish',	'closed',	'open',	'',	'sample-page',	'',	'',	'2023-06-02 05:03:24',	'2023-06-02 05:03:24',	'',	0,	'http://preschool-registration.local/?page_id=2',	0,	'page',	'',	0),
(3,	1,	'2023-06-02 05:03:24',	'2023-06-02 05:03:24',	'<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://preschool-registration.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->',	'Privacy Policy',	'',	'draft',	'closed',	'open',	'',	'privacy-policy',	'',	'',	'2023-06-02 05:03:24',	'2023-06-02 05:03:24',	'',	0,	'http://preschool-registration.local/?page_id=3',	0,	'page',	'',	0),
(4,	1,	'2023-06-02 05:03:50',	'0000-00-00 00:00:00',	'',	'Auto Draft',	'',	'auto-draft',	'open',	'open',	'',	'',	'',	'',	'2023-06-02 05:03:50',	'0000-00-00 00:00:00',	'',	0,	'http://preschool-registration.local/?p=4',	0,	'post',	'',	0),
(8,	1,	'2023-06-02 05:09:35',	'0000-00-00 00:00:00',	'',	'Auto Draft',	'',	'auto-draft',	'closed',	'closed',	'',	'',	'',	'',	'2023-06-02 05:09:35',	'0000-00-00 00:00:00',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&p=8',	0,	'preschool-reg',	'',	0),
(14,	1,	'2023-06-02 05:35:36',	'0000-00-00 00:00:00',	'',	'Auto Draft',	'',	'auto-draft',	'closed',	'closed',	'',	'',	'',	'',	'2023-06-02 05:35:36',	'0000-00-00 00:00:00',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&p=14',	0,	'preschool-reg',	'',	0),
(15,	1,	'2023-06-02 05:37:07',	'2023-06-02 05:37:07',	'',	'Little Explorers',	'',	'publish',	'closed',	'closed',	'',	'little-explorers',	'',	'',	'2023-06-02 06:08:45',	'2023-06-02 06:08:45',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&#038;p=15',	0,	'preschool-reg',	'',	0),
(16,	1,	'2023-06-02 05:37:39',	'2023-06-02 05:37:39',	'',	'Bright Beginnings',	'',	'publish',	'closed',	'closed',	'',	'bright-beginnings',	'',	'',	'2023-06-02 05:37:39',	'2023-06-02 05:37:39',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&#038;p=16',	0,	'preschool-reg',	'',	0),
(17,	1,	'2023-06-02 05:38:11',	'2023-06-02 05:38:11',	'',	'Playful Pals',	'',	'publish',	'closed',	'closed',	'',	'playful-pals',	'',	'',	'2023-06-02 05:38:11',	'2023-06-02 05:38:11',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&#038;p=17',	0,	'preschool-reg',	'',	0),
(18,	1,	'2023-06-02 05:38:40',	'2023-06-02 05:38:40',	'',	'Sunny Days',	'',	'publish',	'closed',	'closed',	'',	'sunny-days',	'',	'',	'2023-06-02 05:38:40',	'2023-06-02 05:38:40',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&#038;p=18',	0,	'preschool-reg',	'',	0),
(19,	1,	'2023-06-02 05:39:11',	'2023-06-02 05:39:11',	'',	'Little Sprouts',	'',	'publish',	'closed',	'closed',	'',	'little-sprouts',	'',	'',	'2023-06-02 05:39:11',	'2023-06-02 05:39:11',	'',	0,	'http://preschool-registration.local/?post_type=preschool-reg&#038;p=19',	0,	'preschool-reg',	'',	0);

-- 2023-06-02 20:29:57
